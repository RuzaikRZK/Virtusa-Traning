package com.example.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.model.AdminDetailes;
import com.example.project.service.AdminSignupService;

@CrossOrigin(origins = "*")

@RestController
@RequestMapping("/AdminSignup")
public class AdminSignupController {

	@Autowired 
	AdminSignupService adminSignupService; 
	
	@RequestMapping(value = "/getAllAdminDetailes")
	public List<AdminDetailes> getAllAdmin() {

		return AdminDetailes.getAllEmployees();

	}
	
	
	@RequestMapping(value = "/SaveAdminDetailes", method = RequestMethod.POST)
	public AdminDetailes Save(@RequestBody AdminDetailes adminDetailes) {
		System.err.println(adminDetailes);
		return adminSignupService.SaveDetailes(adminDetailes);
		
		
	}
	
	@RequestMapping(value = "/test", method = RequestMethod.POST)
	public void test(@RequestHeader HttpHeaders httpHeaders) {
		System.err.println(httpHeaders);
	}

}
