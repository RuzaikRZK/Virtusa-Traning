import {Component, OnInit} from '@angular/core';
import {APIResponse, LoginserviceService} from '../service/loginservice.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username;
  Password;
  invalidLogin = false;
  apiResponse: APIResponse;

  constructor(private router: Router, private loginserviceService: LoginserviceService) {
  }

  ngOnInit(): void {
  }

  goToHome() {
    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port;
  }

  loginUser(): void {
    this.loginserviceService.authenticate(this.username, this.Password).subscribe(data => {
      this.apiResponse = data;

      if (this.apiResponse.message !== 'Failed!') {
        console.log(data);
        sessionStorage.setItem('username', this.username);
        sessionStorage.setItem('accessToken', this.apiResponse.accessToken.access_token);
        sessionStorage.setItem('refreshToken', this.apiResponse.accessToken.refresh_token);

        console.log('Token ekaaaaaaaa   ' + sessionStorage.getItem('accessToken'));

        this.invalidLogin = false;
        /*this.router.navigate(['']);*/
        this.goToHome();
      } else {
        this.invalidLogin = true;
      }
    }, error => {
      console.log(error);
      this.invalidLogin = true;
    });
  }
}
