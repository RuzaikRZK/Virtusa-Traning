import { Injectable } from '@angular/core';
import {User} from 'src/app/signup/user.model';
import {HttpClient, HttpHeaders} from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class SignServiceService {

  constructor(private http: HttpClient ) { }

  private  url = 'http://localhost:2000/AdminSignup/SaveAdminDetailes';


  public createUser(user) {
    return this.http.post<User>(this.url, user);
  }

}
