import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

export class APIResponse {
  constructor(public statusCode: number,
              public message: string,
              public accessToken: AccessToken) {
  }
}

export class AccessToken {
  constructor(public access_token: string,
              public token_type: string,
              public refresh_token: string,
              public expires_in: string,
              public scope: string) {
  }
}

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor(private httpClient: HttpClient) {
  }

  public authenticate(username, password) {
    return this.httpClient.get<APIResponse>('http://localhost:2000/AdminSignup/login/' + username + '/' + password);
  }

  public isUserLoggedIn() {
    const user = sessionStorage.getItem('username');
    return !(user === null);
  }

  public logout() {
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('accessToken');
    sessionStorage.removeItem('refreshToken');
  }
}
