import { Component, OnInit } from '@angular/core';
import { TestserviceService } from 'src/app/testservice.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {

  tutorial = {
    adminName: '',
    email: '',
    password: '',
    contactList : [{

      number : '07759595'

    }]
   

  };
  submitted = false;

  constructor(private TestserviceService:TestserviceService) { }

  ngOnInit(): void {
  }

  saveTutorial() {
    const data = {
      adminName: this.tutorial.adminName,
      email : this.tutorial.email,
      password : this.tutorial.password,
      contactList : this.tutorial.contactList
      
    };

    this.TestserviceService.create(data)
    .subscribe(
      response => {
        console.log(response);
      },
      error => {
        console.log(error);
      });

  this.submitted = true;
}

}
