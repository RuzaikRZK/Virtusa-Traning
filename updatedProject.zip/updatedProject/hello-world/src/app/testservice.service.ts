import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Headers, RequestOptions } from '@angular/http';

const baseUrl = 'http://localhost:2000/AdminSignup/SaveAdminDetailes';



@Injectable({
  providedIn: 'root'
})
export class TestserviceService {

  constructor(private http: HttpClient) { }
  
  create(data) {
    let headers = new Headers({'Authorization': 'bearer fb2ff835-9d90-4620-a68a-238ff4148dca'});
    let options = new RequestOptions({headers : headers});
    //opts.headers = headers;
    
    return this.http.post<any>(baseUrl, data, {
      headers: new HttpHeaders()
      .append("Authorization", "bearer 97933f86-4871-41c9-bade-1ac973660fc4")
      .append("Content-Type", "application/json")
    });
  }
}