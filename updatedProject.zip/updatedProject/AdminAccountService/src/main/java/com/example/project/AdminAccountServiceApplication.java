package com.example.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "*")
@SpringBootApplication
@EnableResourceServer

public class AdminAccountServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminAccountServiceApplication.class, args);
	}

}
