import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/signup/user.model';
import {Router} from '@angular/router';
import {SignServiceService} from 'src/app/service/sign-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})

export class SignupComponent implements OnInit {

  valide ;
   user: User = new User();


  constructor(private  router: Router, private userService: SignServiceService) {


  }

  CrateUser(): void {
  this.userService.createUser(this.user).subscribe( data => {
    console.log(this.user);

    console.log(data.password);
    this.valide = true;
    this.RedirectLogin();


  }, error => {
    console.log(error);
    this.valide = false;
  });
  }

  RedirectLogin() {
    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port + '/login';
  }


  ngOnInit(): void {
  }

}
