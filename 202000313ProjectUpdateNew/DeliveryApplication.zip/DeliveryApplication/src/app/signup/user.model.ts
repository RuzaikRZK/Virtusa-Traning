export class User {

  firstname: string;
  lastName: string;
  username: string;
  password: string;
  nic: string;
  address: string;
  email: string;
  phoneNumber: string;
  role = 'User';


}
