import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeheader',
  templateUrl: './homeheader.component.html',
  styleUrls: ['./homeheader.component.css']
})
export class HomeheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  reloadAbout() {
    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port + '/about';
  }

  reloadLogin() {

    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port + '/login';

  }

  reloadHome() {

    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port;

  }

  reloadOurService() {

    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port + '/ourservice';

  }

  reloadPrice() {

    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port + '/pricing';


  }

  reloadcontact() {

    window.location.href = 'http://' + window.location.hostname + ':' + window.location.port + '/contact';

  }





}
